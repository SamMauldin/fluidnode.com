/============================\
|  Custom Minecraft Server   |
|         (MCServer)         |
|                            |
| Founder: Kevin Bansberg    |
|       A.K.A. FakeTruth     |
| Lead dev: Mattes D         |
|       A.K.A. _Xoft(o)      |
|       A.K.A. xoft          |
| Monsters by Alex Sonek     |
|       A.K.A. Duralex       |
|============================|
| Info: www.mc-server.org    |
|       www.ae-c.net         |
|       www.rbthinktank.com  |
| Mail: faketruth@gmail.com  |
\============================/

Compatible clients: 1.2.4, 1.2.5, 1.3.1, 1.3.2, 1.4.2, 1.4.4, 1.4.5, 1.4.6, 1.4.7, 1.5, 1.5.1, 1.5.2, 1.6.1, 1.6.2, 1.6.3, 1.6.4
Compatible protocol versions: 29, 39, 47, 49, 51, 60, 61, 73, 74, 77, 78
