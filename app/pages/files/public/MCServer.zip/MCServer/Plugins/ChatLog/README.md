ChatLog
=======

A Chat Log plugin for MCServer.

This work is Copyright of the [MCServer Developers](https://github.com/mc-server/MCServer/blob/master/CONTRIBUTORS)
